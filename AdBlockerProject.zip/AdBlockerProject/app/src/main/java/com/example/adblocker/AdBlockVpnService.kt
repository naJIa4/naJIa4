package com.example.adblocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class AdBlockVpnService : VpnService() {

    companion object {
        const val TAG = "AdBlockVPN"
        const val CHANNEL_ID = "adblocker_channel"
        const val NOTIFICATION_ID = 1
        const val DNS_PORT = 53
        val DNS_SERVER: InetAddress = InetAddress.getByName("8.8.8.8")

        val AD_DOMAINS = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "googletagmanager.com", "facebook.com",
            "fbcdn.net", "amazon-adsystem.com", "advertising.com", "adsrvr.org",
            "adsymptotic.com", "moatads.com", "outbrain.com", "taboola.com",
            "scorecardresearch.com", "quantserve.com", "addthis.com", "sharethis.com",
            "an.yandex.ru", "mc.yandex.ru", "ads.yahoo.com", "advertising.yahoo.com",
            "bing.com", "adform.net", "adnxs.com", "appnexus.com", "criteo.com",
            "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net",
            "adsafeprotected.com", "admob.com", "googleadapis.l.google.com",
            "pagead.l.doubleclick.net", "tpc.googlesyndication.com",
            "securepubads.g.doubleclick.net", "ad.doubleclick.net",
            "static.doubleclick.net", "m.doubleclick.net", "mediavisor.doubleclick.net",
            "fls.doubleclick.net", "adservice.google.com",
            "pagead2.googlesyndication.com", "partner.googleadservices.com",
            "www.google-analytics.com", "ssl.google-analytics.com", "analytics.google.com",
            "metrics.apple.com", "iad.apple.com", "banners.itunes.apple.com",
            "appsflyer.com", "app-measurement.com", "crashlytics.com", "flurry.com",
            "inmobi.com", "chartboost.com", "vungle.com", "unityads.unity3d.com",
            "supersonicads.com", "ironsource.com", "startapp.com", "adcolony.com",
            "applovin.com", "mopub.com", "ads-twitter.com", "ads-api.twitter.com",
            "analytics.twitter.com", "ads.linkedin.com", "analytics.linkedin.com",
            "ads.reddit.com", "events.reddit.com", "ads.tiktok.com", "analytics.tiktok.com",
            "ads.snapchat.com", "tr.snapchat.com", "ads.pinterest.com", "log.pinterest.com",
            "mobileapptracking.com", "adjust.com", "kochava.com", "tapjoy.com",
            "smartadserver.com", "adzerk.net", "adsystem.google.com", "atdmt.com",
            "bluekai.com", "contextweb.com", "exelator.com", "mathtag.com", "turn.com",
            "tribalfusion.com", "viglink.com", "zedo.com", "adroll.com", "adstir.com",
            "adingo.jp", "i-mobile.co.jp", "microad.jp", "nend.net", "ad-plus.cn",
            "adchina.com", "adview.cn", "domob.cn", "umeng.com", "miaozhen.com",
            "admaster.com.cn", "irs01.com", "allyes.com", "mediav.com", "tanx.com",
            "alimama.com", "mmstat.com", "cnzz.com", "cpro.baidu.com", "pos.baidu.com",
            "hm.baidu.com", "union.baidu.com", "ad.qq.com", "e.qq.com", "gdt.qq.com",
            "beacon.qq.com", "bugly.qq.com", "mob.com", "adwhirl.com", "greystripe.com",
            "millennialmedia.com"
        )
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    @Volatile private var isRunning = false
    private var vpnThread: Thread? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopVpn()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, createNotification())
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (isRunning) return
        try {
            val builder = Builder()
                .setSession("AdBlocker")
                .addAddress("10.0.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("8.8.4.4")
                .allowFamily(android.system.OsConstants.AF_INET)
                .setBlocking(true)
                .setMtu(1500)

            vpnInterface = builder.establish()
            isRunning = true
            vpnThread = Thread { vpnLoop() }.apply { start() }
            Log.i(TAG, "VPN started, ad blocking active")
        } catch (e: Exception) {
            Log.e(TAG, "VPN start error", e)
            stopSelf()
        }
    }

    private fun vpnLoop() {
        val fd = vpnInterface?.fileDescriptor ?: return
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val buffer = ByteArray(32767)
        val dnsSocket = DatagramSocket()
        protect(dnsSocket)

        while (isRunning) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val packet = buffer.copyOfRange(0, length)
                if (isDnsPacket(packet)) {
                    val domain = extractDomainFromDns(packet)
                    if (domain != null && isAdDomain(domain)) {
                        Log.d(TAG, "BLOCKED: $domain")
                        continue
                    }
                }
                forwardPacket(packet, dnsSocket, output)
            } catch (e: Exception) {
                if (isRunning) Log.e(TAG, "Packet error", e)
            }
        }
        try { dnsSocket.close() } catch (_: Exception) {}
    }

    private fun isDnsPacket(packet: ByteArray): Boolean {
        if (packet.size < 28) return false
        val ipVersion = (packet[0].toInt() shr 4) and 0xF
        if (ipVersion != 4) return false
        val ipHeaderLen = (packet[0].toInt() and 0xF) * 4
        if (packet.size < ipHeaderLen + 8) return false
        val protocol = packet[9].toInt() and 0xFF
        if (protocol != 17) return false
        val destPort = ((packet[ipHeaderLen + 2].toInt() and 0xFF) shl 8) or
                (packet[ipHeaderLen + 3].toInt() and 0xFF)
        return destPort == DNS_PORT
    }

    private fun extractDomainFromDns(packet: ByteArray): String? {
        val ipHeaderLen = (packet[0].toInt() and 0xF) * 4
        val dnsOffset = ipHeaderLen + 8
        if (packet.size < dnsOffset + 12) return null
        val flags = ((packet[dnsOffset + 2].toInt() and 0xFF) shl 8) or
                (packet[dnsOffset + 3].toInt() and 0xFF)
        val isQuery = (flags shr 15) == 0
        if (!isQuery) return null
        var offset = dnsOffset + 12
        val labels = mutableListOf<String>()
        while (offset < packet.size) {
            val len = packet[offset].toInt() and 0xFF
            if (len == 0) break
            if (len > 63 || offset + len + 1 > packet.size) return null
            labels.add(String(packet, offset + 1, len, Charsets.UTF_8))
            offset += len + 1
        }
        return if (labels.isNotEmpty()) labels.joinToString(".") else null
    }

    private fun isAdDomain(domain: String): Boolean {
        return AD_DOMAINS.any { domain.lowercase().contains(it) }
    }

    private fun forwardPacket(packet: ByteArray, dnsSocket: DatagramSocket, output: FileOutputStream) {
        try {
            val ipHeaderLen = (packet[0].toInt() and 0xF) * 4
            val dnsOffset = ipHeaderLen + 8
            val dnsData = packet.copyOfRange(dnsOffset, packet.size)
            dnsSocket.send(DatagramPacket(dnsData, dnsData.size, DNS_SERVER, DNS_PORT))
            val respBuf = ByteArray(4096)
            val response = DatagramPacket(respBuf, respBuf.size)
            dnsSocket.receive(response)
            val responsePacket = buildResponsePacket(packet, response.data.copyOfRange(0, response.length))
            output.write(responsePacket)
        } catch (e: Exception) {
            Log.e(TAG, "Forward error", e)
        }
    }

    private fun buildResponsePacket(original: ByteArray, dnsResponse: ByteArray): ByteArray {
        val ipHeaderLen = (original[0].toInt() and 0xF) * 4
        val totalLen = ipHeaderLen + 8 + dnsResponse.size
        val packet = ByteArray(totalLen)
        System.arraycopy(original, 0, packet, 0, ipHeaderLen)
        for (i in 0..3) {
            val tmp = packet[12 + i]
            packet[12 + i] = packet[16 + i]
            packet[16 + i] = tmp
        }
        packet[2] = (totalLen shr 8).toByte()
        packet[3] = (totalLen and 0xFF).toByte()
        packet[10] = 0
        packet[11] = 0
        val udpOff = ipHeaderLen
        System.arraycopy(original, udpOff, packet, udpOff + 2, 2)
        System.arraycopy(original, udpOff + 2, packet, udpOff, 2)
        val udpLen = 8 + dnsResponse.size
        packet[udpOff + 4] = (udpLen shr 8).toByte()
        packet[udpOff + 5] = (udpLen and 0xFF).toByte()
        packet[udpOff + 6] = 0
        packet[udpOff + 7] = 0
        System.arraycopy(dnsResponse, 0, packet, udpOff + 8, dnsResponse.size)
        return packet
    }

    private fun stopVpn() {
        isRunning = false
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        vpnThread?.interrupt()
        vpnThread = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
        Log.i(TAG, "VPN stopped")
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "AdBlocker VPN", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val stopIntent = Intent(this, AdBlockVpnService::class.java).apply { action = "STOP" }
        val pending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AdBlocker active")
            .setContentText("Ads are being blocked via VPN")
            .setSmallIcon(android.R.drawable.ic_secure)
            .addAction(android.R.drawable.ic_media_pause, "Stop", pending)
            .setOngoing(true)
            .build()
    }
}
