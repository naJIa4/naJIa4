package com.example.adblocker

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private var isVpnRunning = false

    private val vpnLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) startVpnService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnClickListener {
            if (isVpnRunning) stopVpnService() else prepareVpn()
        }
        updateUI()
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnLauncher.launch(intent) else startVpnService()
    }

    private fun startVpnService() {
        startService(Intent(this, AdBlockVpnService::class.java))
        isVpnRunning = true
        updateUI()
    }

    private fun stopVpnService() {
        startService(Intent(this, AdBlockVpnService::class.java).apply { action = "STOP" })
        isVpnRunning = false
        updateUI()
    }

    private fun updateUI() {
        if (isVpnRunning) {
            statusText.text = getString(R.string.status_active)
            toggleButton.text = getString(R.string.stop_protection)
        } else {
            statusText.text = getString(R.string.status_inactive)
            toggleButton.text = getString(R.string.start_protection)
        }
    }
}
