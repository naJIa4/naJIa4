# AdBlocker VPN — Android

Ad blocker using local VPN + DNS filtering.

## How to get APK

1. Go to **Actions** tab
2. Click **"Build APK"**
3. Click **"Run workflow"**
4. Wait 3-5 minutes
5. Download APK from **Artifacts**

## Features

- Blocks 100+ ad and tracker domains
- Local VPN (no external server)
- DNS query filtering
- Works in browser and apps

## Limitations

- YouTube ads not blocked
- IPv6 not supported
- DoH/DoT bypasses blocking
